package pp;
import java.util.*;
public class Use{
	
	private int choice=0;
	private int flag=0;
	private int pflag1=0;
	Scanner sc=new Scanner(System.in);
	
	Money j=new Money();
	
	public void start(){
	System.out.println("\nwhat can we do for you?\n");
	
	try{
	do{
	
	System.out.println("==============================================================================================="); 
	System.out.println("Plese Enter your choice"); 
	System.out.println("1.Add account\t2.Check balance\t3.Add money\t     4.Withdraw money\t5.Tranfer money\n6.Bank details\t7.Set password\t8.Forgot password    9.About\t        0.exit ");
	 
	 choice=sc.nextInt();
	
	  
	  switch(choice){
	  
		case 1:
			if (flag==0){
				j.new1();
				flag++;
			}
			else{
					System.out.println("You already have a Account"); 
			}
		break;
	  
		case 2:
		if (flag==1){
			j.check();
			}
			else{
			System.out.println("You don't have a Account"); 
			}
		break;
	  
		case 3:
		if (flag==1){
			j.add1();
		}
		else{
			System.out.println("You don't have a Account"); 
		}
		break;
					
		case 4:
		if ((flag==1)&&(pflag1!=0)){
			j.withdraw();
		}
		else{
			System.out.println("You don't have a Account Or Password is not set"); 
		}
		break;

		case 5:
		if ((flag==1)&&(pflag1!=0)){
			j.transfer();
		}
		else{
			System.out.println("You don't have a Account Or Password is not set"); 
		}
		break;

		case 6:
		if (flag==1){
			j.info();
		}
		else{
			System.out.println("You don't have a Account"); 
		}
		break;
			
		case 7:
		if (flag==1){
			//System.out.println("Disclaimer: There is no Forgot password option so always remember the password");
			j.setpass();
			pflag1++;
		}
		else{
			System.out.println("You don't have a Account"); 
		}
		break;
		
		case 9:
			System.out.println("--------------------------------------------------------------------------------------------\n ");
			System.out.println("Thanks to connecting with CDAC Bank....\nThis application is devloped by Team-2 of Team Garud.\n ");
			System.out.println("\nDevlopers:1.Kalyani\t2.Jayram");
			System.out.println("\nHelping Hands :-TEAM GARUD(Team 5 JUHU)\n1.Jagruti\n2.Jayant\n3.Karan\n4.Ketan\n5.Kiran\n6.komal\n7.Kunal\n8.kumar"); 
			System.out.println("\nGuidence:Vipul sir");
			System.out.println("");
			System.out.println("This programme is under devlopment..if you you find any BUG please contact devlopers..\n");
			System.out.println("--------------------------------------------------------------------------------------------\n ");
		break;
			
			case 0 : break;
			
			case 8:
			j.forgot();
			System.out.println("Password is forgotten please create new password"); 
			break;
		default:
			System.out.println("Invalid Input"); 
		}
				/*System.out.print("Press 0 to EXIT or 1 to CONTINUE :"); 
				choice=sc.nextInt();*/
		/**/
		
	
	}while(choice!=0);
	}catch(Throwable o){
		System.out.println("Invalid Input");
		}
	}	
}
