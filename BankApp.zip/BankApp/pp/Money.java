package pp;
import java.util.*;

class Account{
	Scanner sc =new Scanner(System.in);
	
	String ahold;
	String accno="10001";
	String pnum;
	String add;
	static String pass;
	int pflag=0;
	
	static int amt;
	 
	void new1(){
		 
	 System.out.println("\nPlease fill the following deatails to create the account ");
		 System.out.println("======================================================================================= ");
		
		System.out.println();
		System.out.print("Name : ");
		ahold=sc.nextLine();
		
		System.out.print("\nPhone number :");
		pnum=sc.nextLine();
		
		System.out.print("\nAddress :");
		add=sc.nextLine();
				
		System.out.println("\n\nYour account is created succesfully\nyour account number is "+accno+"\n \nTHANKS FOR CONNECTING WITH US!!!!!");
		System.out.println("\n===========================================================================================\n ");
				 
	 }
	 void info(){
		 
         System.out.println("\n===========================================================================================\n ");
		 System.out.print("Name : "+ahold);
		 System.out.print("\nPhone number :"+pnum);
		 System.out.println("\nAddress :"+add);
		 System.out.println("\naccount number = "+accno);
         System.out.println("\n===========================================================================================\n ");
		}
void setpass(){
		
	}
	 
}
class Transaction extends Account{
	
	//boolean bpass=false;
    String pass3;
	//int count=0;*/
	Scanner sc =new Scanner(System.in);

	@Override
	void setpass(){
		
		if (pflag==0){	
			do{
		System.out.print("\nCreate Password :");
		 String pass1=sc.nextLine();
		System.out.print("\nConfirm Password :");
		String pass2=sc.nextLine();
			if(pass1.equals(pass2)){
				System.out.println("Passwords is successfully updated");
				pass=pass1;
				pflag=1;
                
			}
			else{
				System.out.println("\nPasswords not match.....!!!");
			}
			}while(pflag==0);
		}
		
		else if(pflag==1){
			
			
				System.out.print("Please enter the old Passwords : ");
			 	pass3=sc.nextLine();
				 

				if(pass.equals(pass3)){
					pflag=0;

					do{
						System.out.print("\nNew Password :");
						String pass1=sc.nextLine();
						System.out.print("\nConfirm Password :");
						String pass2=sc.nextLine();

						if(pass1.equals(pass2)){
							System.out.println("Passwords is successfully updated");
							pass=pass1;
							pflag=1;
                            
						}
						else{
							System.out.print("\nPasswords not match");
						}

					}while(pflag==0);
				
				}
				else{
					System.out.println("\n Wrong Password input....!!!! ");	
				}

		}
	}
	
	 void forgot(){
			pflag=0;
		}
}

	


public class Money extends Transaction{

	String s="";

	void check(){
		System.out.println("--------------------------------------------------------------------------------------------\n ");
		System.out.println("Your Account Balance is ="+amt+" Rs.");
		System.out.println("\n--------------------------------------------------------------------------------------------\n ");
	}

	void add1(){
	
	try{
		System.out.print("Enter the Ammount to be add in Account = ");
		int a=sc.nextInt();
		
		amt=amt+a;
		System.out.println("Ammount is added succesfully");
		}
		 catch(Throwable e){
	 System.out.println("Wrong input...."); 
	}
	}

	void withdraw(){
		
		try{
		boolean b= pass1();
		if (b){
		System.out.print("Enter the Ammount to be Withdraw from Account  = ");
		int a=sc.nextInt();
		
			if (amt>a){
				amt=amt-a;
				}
			else{
				System.out.print("Don't have enough balaence to proceed.........");
			}
		
		}
		}
		 catch(NullPointerException e){
	 System.out.println("password is not set"); 
	}
	}
	
	void transfer(){
		
		try{
		 boolean b= pass1();
		if (b){
			System.out.print("Enter the  reciever's Account no: ");
			int s1=sc.nextInt();
			System.out.print("Enter the Ammount to be Transfer from Account  = ");
			int a=sc.nextInt();
			if (amt>a){
				amt=amt-a;
				}
			else{
				System.out.print("Don't have enough balance to proceed.........");
				}
			}
		}catch(NullPointerException e){
	 System.out.println("password is not set"); 
	}catch(InputMismatchException e){
	 System.out.println("Wrong Input.."); 
	}catch(Throwable e){
	 System.out.println("Wrong Input.."); 
	}
	}
	
	boolean pass1(){
		try{
			if (pass!=null){
		System.out.print("Enter the password: ");
		Scanner s=new Scanner(System.in);
		String pass5=s.nextLine();

		 return(pass.equals(pass5));
			}else{
				System.out.print("Please set password First... ");}
		 }
		 catch(NullPointerException e){
	  System.out.println("password is not set"); 
	}
	return false;
}
}